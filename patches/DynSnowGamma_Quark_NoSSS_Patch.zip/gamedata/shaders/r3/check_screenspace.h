// DynSnow Standalone Fallback Stub (for setups without Screen Space Shaders)

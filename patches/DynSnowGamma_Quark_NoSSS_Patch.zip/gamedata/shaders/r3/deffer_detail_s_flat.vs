#include "common.h"
uniform float4 consts;
uniform float4 array[61*4];

v2p_flat main(v_detail v)
{
	v2p_flat O = (v2p_flat)0;
	int i = v.misc.w;
	float4 m0 = array[i+0];
	float4 m1 = array[i+1];
	float4 m2 = array[i+2];
	float4 c0 = array[i+3];

	float4 pos = float4(dot(m0, v.pos), dot(m1, v.pos), dot(m2, v.pos), 1.0f);
	float3 norm = float3(pos.x - m0.w, pos.y - m1.w + 0.75f, pos.z - m2.w);
	O.hpos = mul(m_WVP, pos);
	float3 orig = mul(m_WV, normalize(norm));
	O.N = lerp(orig, mul((float3x3)m_WV, v.pos), 0.25f);
	O.tcdh = float4((v.misc * consts).xyyy);
#if defined(USE_R2_STATIC_SUN) && !defined(USE_LM_HEMI)
	O.tcdh.w = c0.x;
#endif
	O.position = float4(mul(m_WV, pos), c0.w);
	return O;
}
FXVS;

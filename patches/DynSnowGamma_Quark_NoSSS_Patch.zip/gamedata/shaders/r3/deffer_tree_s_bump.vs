#include "common.h"
uniform float3x4 m_xform;
uniform float3x4 m_xform_v;
uniform float4 consts;
uniform float4 c_scale, c_bias;
uniform float2 c_sun;

v2p_bumped main(v_tree I)
{
	I.Nh = unpack_D3DCOLOR(I.Nh);
	I.T  = unpack_D3DCOLOR(I.T);
	I.B  = unpack_D3DCOLOR(I.B);

	float3 pos = mul(m_xform, I.P);
	float4 wpos = float4(pos, 1.0f);
	v2p_bumped O = (v2p_bumped)0;
	O.tcdh = float4((I.tc * consts).xyyy);
	O.hpos = mul(m_VP, wpos);
	O.position = float4(mul(m_V, wpos), I.Nh.w * c_scale.w + c_bias.w);

#if defined(USE_R2_STATIC_SUN) && !defined(USE_LM_HEMI)
	O.tcdh.w = I.Nh.w * c_sun.x + c_sun.y;
#endif
	float3 N = unpack_bx4(I.Nh);
	float3 T = unpack_bx4(I.T);
	float3 B = unpack_bx4(I.B);
	float3x3 xform = mul((float3x3)m_xform_v, float3x3(
		T.x, B.x, N.x,
		T.y, B.y, N.y,
		T.z, B.z, N.z
	));
	O.M1 = xform[0];
	O.M2 = xform[1];
	O.M3 = xform[2];
#ifdef USE_TDETAIL
	O.tcdbump = O.tcdh * dt_params;
#endif
	return O;
}
FXVS;

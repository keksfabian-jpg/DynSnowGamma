#include "common.h"
uniform float3x4 m_xform;
uniform float3x4 m_xform_v;
uniform float4 consts;
uniform float4 c_scale, c_bias;
uniform float2 c_sun;

v2p_flat main(v_tree I)
{
	I.Nh = unpack_D3DCOLOR(I.Nh);
	float4 wpos = float4(mul(m_xform, I.P), 1.0f);
	v2p_flat O = (v2p_flat)0;
	O.hpos = mul(m_VP, wpos);
	O.N = mul((float3x3)m_xform_v, unpack_bx2(I.Nh));
	O.tcdh = float4((I.tc * consts).xyyy);
	O.position = float4(mul(m_V, wpos), I.Nh.w * c_scale.w + c_bias.w);
#if defined(USE_R2_STATIC_SUN) && !defined(USE_LM_HEMI)
	O.tcdh.w = I.Nh.w * c_sun.x + c_sun.y;
#endif
#ifdef USE_TDETAIL
	O.tcdbump = O.tcdh * dt_params;
#endif
	return O;
}
FXVS;
